﻿
using System;

namespace SocketServer
{
    public class ServMain
    {
        static private void Main(string[] str)
        {
            Server _serv = new Server();
            SQL sql = new SQL();
            while (true)
            {
                string _str = Console.ReadLine();
                if (_str.Equals("OpenO"))
                {
                    _serv.OpenServ("127.0.0.1", 8888);  //正式服
                }
                else if (_str.Equals("OpenT"))
                {
                    _serv.OpenServ("127.0.0.1", 7777);  //测试服
                }
                else if (_str.Equals("Quit"))
                {
                    _serv.CloseServ();
                    break;
                }



            }
        }
    }
}
